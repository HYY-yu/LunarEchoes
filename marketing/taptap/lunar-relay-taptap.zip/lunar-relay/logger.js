export function log(level, event, details = {}) {
    const entry = { scope: 'lunar-relay', event, ...details };
    if (level === 'debug') {
        if (new URLSearchParams(location.search).has('debug'))
            console.debug(entry);
    }
    else
        console[level](entry);
}
