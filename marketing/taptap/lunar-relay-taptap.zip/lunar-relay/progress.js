import { STAGE_ORDER } from './stage-contract.js';
export function decodeProgress(raw) {
    if (raw === null)
        return { kind: 'missing' };
    let value;
    try {
        value = JSON.parse(raw);
    }
    catch {
        return { kind: 'rejected', reason: 'invalid_json', raw };
    }
    if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        return { kind: 'rejected', reason: 'invalid_type', raw };
    }
    if (!('version' in value) || typeof value.version !== 'number' || !Number.isInteger(value.version)) {
        return { kind: 'rejected', reason: 'invalid_version', raw };
    }
    if (value.version !== 1)
        return { kind: 'rejected', reason: 'unknown_version', raw };
    if (Object.keys(value).length !== 2 || !('highestUnlockedStageId' in value)) {
        return { kind: 'rejected', reason: 'invalid_fields', raw };
    }
    if (typeof value.highestUnlockedStageId !== 'string') {
        return { kind: 'rejected', reason: 'invalid_type', raw };
    }
    for (const id of STAGE_ORDER) {
        if (value.highestUnlockedStageId === id) {
            return { kind: 'valid', progress: Object.freeze({ version: 1, highestUnlockedStageId: id }) };
        }
    }
    return { kind: 'rejected', reason: 'unknown_stage', raw };
}
export function encodeProgress(progress) {
    return JSON.stringify({ version: 1, highestUnlockedStageId: progress.highestUnlockedStageId });
}
export function createInitialProgress() {
    return Object.freeze({ version: 1, highestUnlockedStageId: STAGE_ORDER[0] });
}
export function isStageUnlocked(input) {
    return STAGE_ORDER.indexOf(input.stageId) <= STAGE_ORDER.indexOf(input.progress.highestUnlockedStageId);
}
export function applyStageResult(input) {
    const { progress, stageId, source, outcome } = input;
    if (source !== 'live' && source !== 'replay')
        throw new TypeError('Invalid stage result source');
    if (outcome !== 'won' && outcome !== 'lost')
        throw new TypeError('Invalid stage result outcome');
    if (!isStageUnlocked({ progress, stageId }))
        return { kind: 'locked' };
    if (source !== 'live' || outcome !== 'won')
        return { kind: 'unchanged' };
    const nextStageId = STAGE_ORDER[STAGE_ORDER.indexOf(stageId) + 1];
    if (nextStageId === undefined || isStageUnlocked({ progress, stageId: nextStageId }))
        return { kind: 'unchanged' };
    return { kind: 'advanced', progress: Object.freeze({ version: 1, highestUnlockedStageId: nextStageId }) };
}
