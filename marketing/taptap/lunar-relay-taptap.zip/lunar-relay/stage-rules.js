function context(stageId, revision) {
    return Object.freeze({ stageId, rulesVersion: `${stageId}-${revision}` });
}
export const DESERT_CONTEXT = context('desert-base', 1);
export const RAINFOREST_CONTEXT = context('rainforest', 1);
export const ANTARCTICA_CONTEXT = context('antarctica', 1);
export const SPACE_ELEVATOR_CONTEXT = context('space-elevator', 1);
export const WATCHTOWER_CONTEXT = context('watchtower', 1);
export const LUNAR_ECHOES_CONTEXT = context('lunar-echoes', 1);
const LEGACY_CONTEXTS = Object.freeze({
    'desert-base': DESERT_CONTEXT,
    rainforest: RAINFOREST_CONTEXT,
    antarctica: ANTARCTICA_CONTEXT,
    'space-elevator': SPACE_ELEVATOR_CONTEXT,
    watchtower: WATCHTOWER_CONTEXT,
    'lunar-echoes': LUNAR_ECHOES_CONTEXT
});
const CONTEXTS = Object.freeze({
    'desert-base': context('desert-base', 2),
    rainforest: context('rainforest', 2),
    antarctica: context('antarctica', 2),
    'space-elevator': context('space-elevator', 2),
    watchtower: context('watchtower', 2),
    'lunar-echoes': context('lunar-echoes', 2)
});
export class SimulationError extends Error {
    code;
    constructor(code) {
        super(code === 'incompatible-version' ? 'Replay version mismatch' : code);
        this.code = code;
        this.name = 'SimulationError';
    }
}
const DESERT_RULES = Object.freeze({ kind: 'desert', durationTicks: 60 * 180, arenaSize: 1500, bossSpawnTick: 60 * 140 });
const RAINFOREST_RULES = Object.freeze({
    kind: 'rainforest', durationTicks: 60 * 195, arenaSize: 1500, bossSpawnTick: 60 * 155,
    sentryStartTick: 60 * 18, lateWaveTick: 60 * 90, sentryChance: .24, lateSentryChance: .34, minimumSpawnInterval: 15
});
function wave(startSecond, intervalTicks, sentryChance, droneChance) {
    return Object.freeze({ startTick: 60 * startSecond, intervalTicks, sentryChance, droneChance });
}
function campaign(durationSeconds, bossSecond, crawlerHp, waves, boss) {
    return Object.freeze({
        kind: 'campaign', durationTicks: 60 * durationSeconds, arenaSize: 1500, bossSpawnTick: 60 * bossSecond,
        crawlerHp, waves: Object.freeze(waves), boss: Object.freeze(boss)
    });
}
const RULES = Object.freeze({
    'desert-base': DESERT_RULES,
    rainforest: RAINFOREST_RULES,
    antarctica: campaign(210, 162, 43, [
        wave(0, 61, 0, 0),
        wave(36, 52, .24, .08),
        wave(82, 38, .30, .10),
        wave(126, 26, .32, .12),
        wave(173, 16, .27, .12)
    ], { hp: 1050, speed: .57, shotCount: 7, aim: 'fan', fanStep: .17, shotSpeed: 2.3, cooldownTicks: 142 }),
    'space-elevator': campaign(205, 158, 30, [
        wave(0, 61, 0, .32),
        wave(29, 50, .10, .42),
        wave(76, 35, .14, .49),
        wave(120, 24, .18, .50),
        wave(167, 16, .16, .56)
    ], { hp: 925, speed: 1.05, shotCount: 3, aim: 'fan', fanStep: .14, shotSpeed: 2.8, cooldownTicks: 103 }),
    watchtower: campaign(225, 173, 32, [
        wave(0, 63, 0, .08),
        wave(25, 48, .17, .22),
        wave(62, 30, .23, .27),
        wave(89, 53, .09, .21),
        wave(105, 25, .28, .24),
        wave(144, 40, .17, .29),
        wave(164, 15, .28, .34)
    ], { hp: 1100, speed: .72, shotCount: 10, aim: 'ring', shotSpeed: 2.4, cooldownTicks: 113 }),
    'lunar-echoes': campaign(240, 185, 35, [
        wave(0, 59, 0, .14),
        wave(22, 45, .16, .26),
        wave(66, 36, .24, .34),
        wave(112, 25, .30, .36),
        wave(155, 17, .32, .32),
        wave(201, 13, .34, .34)
    ], { hp: 1250, speed: .79, shotCount: 15, aim: 'ring', shotSpeed: 2.5, cooldownTicks: 120 })
});
function isStageId(stageId) {
    return typeof stageId === 'string' && Object.hasOwn(CONTEXTS, stageId);
}
export function stageContext(stageId) {
    return CONTEXTS[stageId];
}
export function resolveStage(stageId, rulesVersion) {
    if (!isStageId(stageId))
        throw new SimulationError('unavailable-stage');
    const legacy = LEGACY_CONTEXTS[stageId];
    if (rulesVersion === legacy.rulesVersion)
        return legacy;
    const stage = stageContext(stageId);
    if (rulesVersion !== stage.rulesVersion)
        throw new SimulationError('incompatible-rules');
    return stage;
}
export function stageRules(context) {
    return RULES[resolveStage(context.stageId, context.rulesVersion).stageId];
}
