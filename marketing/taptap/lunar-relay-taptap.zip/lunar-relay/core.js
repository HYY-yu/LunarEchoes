import { resolveStage, stageRules, SimulationError } from './stage-rules.js';
export const VERSION = 'lunar-2';
export const HZ = 60;
export const ARMOR_RULES = Object.freeze({ hpPerCell: 10, initialCells: 5, hullCapacityCells: 2, hullRepairCells: 1, repairEveryTicks: HZ * 30 });
const LEGACY_ARMOR_RULES = Object.freeze({ ...ARMOR_RULES, initialCells: 10, hullRepairCells: 4 });
function armorRules(context) { return context.rulesVersion.endsWith('-1') ? LEGACY_ARMOR_RULES : ARMOR_RULES; }
export const UPGRADE_ORDER = Object.freeze(['pulse', 'orbit', 'nova', 'boots', 'hull', 'magnet']);
export function createWorld(request) {
    if (!object(request))
        throw new SimulationError('invalid-data');
    keys(request, ['stageId', 'rulesVersion', 'seed']);
    const context = resolveStage(request.stageId, request.rulesVersion), rules = stageRules(context);
    const seed = parseSeed(request.seed), armor = armorRules(context);
    const world = { context, seed, rng: seed || 1, tick: 0, phase: { kind: 'running' }, nextId: 1,
        player: { x: rules.arenaSize / 2, y: rules.arenaSize / 2, hp: armor.initialCells * armor.hpPerCell, maxHp: armor.initialCells * armor.hpPerCell, invincible: 0, dashCooldown: 0, dashTicks: 0, dx: 1, dy: 0 },
        enemies: [], shots: [], crystals: [], effects: [], events: [], level: 1, xp: 0, threshold: 5, kills: 0,
        upgrades: { pulse: 1, orbit: 0, nova: 0, boots: 0, hull: 0, magnet: 0 }, fireCooldown: 0, novaCooldown: 0, spawnCooldown: 45, bossSpawned: false, bossKilled: false };
    Object.defineProperties(world, { context: { writable: false, configurable: false }, seed: { writable: false, configurable: false } });
    return world;
}
export function random(world) {
    let n = world.rng;
    n ^= n << 13;
    n ^= n >>> 17;
    n ^= n << 5;
    world.rng = n >>> 0;
    return world.rng / 4294967296;
}
export function normalizeInput(input) {
    const x = Number.isFinite(input.x) ? Math.max(-1, Math.min(1, input.x)) : 0;
    const y = Number.isFinite(input.y) ? Math.max(-1, Math.min(1, input.y)) : 0;
    const length = Math.max(1, Math.hypot(x, y));
    return { x: x / length, y: y / length, dash: input.dash === true };
}
function clamp(world, n) { return Math.max(36, Math.min(stageRules(world.context).arenaSize - 36, n)); }
function distance(x, y, bx, by) { return Math.hypot(x - bx, y - by); }
function spawn(world, kind, hitPoints) {
    const angle = random(world) * Math.PI * 2;
    const d = kind === 'boss' ? 350 : 400 + random(world) * 100;
    const hp = hitPoints ?? (kind === 'boss' ? 950 : kind === 'sentry' ? 50 : kind === 'drone' ? 22 : 30);
    let x = clamp(world, world.player.x + Math.cos(angle) * d), y = clamp(world, world.player.y + Math.sin(angle) * d);
    if (distance(x, y, world.player.x, world.player.y) < 250) {
        x = clamp(world, world.player.x - Math.cos(angle) * d);
        y = clamp(world, world.player.y - Math.sin(angle) * d);
    }
    world.enemies.push({ id: world.nextId++, kind, x, y, hp, maxHp: hp, radius: kind === 'boss' ? 27 : kind === 'sentry' ? 15 : 11, attack: 75 + Math.floor(random(world) * 120), flash: 0 });
}
function kill(world, enemy) {
    world.kills++;
    world.crystals.push({ x: enemy.x, y: enemy.y, value: enemy.kind === 'boss' ? 20 : enemy.kind === 'sentry' ? 3 : 1 });
    world.effects.push({ x: enemy.x, y: enemy.y, kind: 'kill', life: 24, size: enemy.radius });
    world.events.push('kill');
    if (enemy.kind === 'boss')
        world.bossKilled = true;
}
function damagePlayer(world) {
    const p = world.player;
    if (p.invincible > 0 || p.dashTicks > 0)
        return;
    p.hp = Math.max(0, p.hp - ARMOR_RULES.hpPerCell);
    p.invincible = 60;
    world.events.push('hit');
    world.effects.push({ x: p.x, y: p.y, kind: 'hit', life: 20, size: 18 });
    if (p.hp === 0) {
        world.phase = { kind: 'lost' };
        world.events.push('lost');
    }
}
function offers(world) {
    const pool = [...UPGRADE_ORDER];
    const result = [];
    while (result.length < 3)
        result.push(pool.splice(Math.floor(random(world) * pool.length), 1)[0]);
    return result;
}
export function dispatch(world, action) {
    world.events.length = 0;
    if (action.kind === 'pause') {
        if (world.phase.kind === 'running')
            world.phase = { kind: 'paused', previous: 'running' };
        return;
    }
    if (action.kind === 'resume') {
        if (world.phase.kind === 'paused')
            world.phase = { kind: 'running' };
        return;
    }
    if (action.kind === 'choose') {
        if (world.phase.kind !== 'upgrading' || !world.phase.offers.includes(action.upgrade))
            return;
        world.upgrades[action.upgrade]++;
        if (action.upgrade === 'hull') {
            world.player.maxHp += ARMOR_RULES.hullCapacityCells * ARMOR_RULES.hpPerCell;
            world.player.hp = Math.min(world.player.maxHp, world.player.hp + armorRules(world.context).hullRepairCells * ARMOR_RULES.hpPerCell);
        }
        world.phase = { kind: 'running' };
        world.events.push('upgrade');
        return;
    }
    if (world.phase.kind !== 'running')
        return;
    step(world, normalizeInput(action.input));
}
function step(world, input) {
    world.tick++;
    const rules = stageRules(world.context), p = world.player;
    if (p.invincible > 0)
        p.invincible--;
    if (p.dashCooldown > 0)
        p.dashCooldown--;
    if (input.dash && p.dashCooldown === 0 && (input.x !== 0 || input.y !== 0)) {
        p.dashTicks = 12;
        p.dashCooldown = 150;
        p.dx = input.x;
        p.dy = input.y;
        world.events.push('dash');
    }
    const speed = 2.5 + world.upgrades.boots * .24;
    if (p.dashTicks > 0) {
        p.dashTicks--;
        p.x = clamp(world, p.x + p.dx * 8);
        p.y = clamp(world, p.y + p.dy * 8);
        if (world.tick % 2 === 0)
            world.effects.push({ x: p.x, y: p.y, kind: 'dash', life: 16, size: 10 });
    }
    else {
        p.x = clamp(world, p.x + input.x * speed);
        p.y = clamp(world, p.y + input.y * speed);
    }
    if (input.x !== 0 || input.y !== 0) {
        p.dx = input.x;
        p.dy = input.y;
    }
    if (world.tick % ARMOR_RULES.repairEveryTicks === 0)
        p.hp = Math.min(p.maxHp, p.hp + ARMOR_RULES.hpPerCell);
    world.spawnCooldown--;
    if (world.spawnCooldown <= 0 && world.enemies.length < 180) {
        const t = world.tick / HZ;
        if (rules.kind === 'rainforest') {
            const chance = world.tick >= rules.lateWaveTick ? rules.lateSentryChance : rules.sentryChance;
            spawn(world, world.tick >= rules.sentryStartTick && random(world) < chance ? 'sentry' : 'crawler');
            world.spawnCooldown = Math.max(rules.minimumSpawnInterval, 60 - Math.floor(t / 3));
        }
        else if (rules.kind === 'campaign') {
            let currentWave = rules.waves[0];
            for (const wave of rules.waves) {
                if (world.tick < wave.startTick)
                    break;
                currentWave = wave;
            }
            const roll = random(world);
            const kind = roll < currentWave.sentryChance ? 'sentry'
                : roll < currentWave.sentryChance + currentWave.droneChance ? 'drone' : 'crawler';
            spawn(world, kind, kind === 'crawler' ? rules.crawlerHp : undefined);
            world.spawnCooldown = currentWave.intervalTicks;
        }
        else {
            const kind = t > 30 && random(world) < .2 ? 'sentry' : t > 12 && random(world) < .35 ? 'drone' : 'crawler';
            spawn(world, kind);
            world.spawnCooldown = Math.max(13, 60 - Math.floor(t / 3));
        }
    }
    const campaignBoss = rules.kind === 'campaign' ? rules.boss : undefined;
    if (world.tick >= rules.bossSpawnTick && !world.bossSpawned) {
        spawn(world, 'boss', campaignBoss?.hp);
        world.bossSpawned = true;
        world.events.push('boss');
    }
    world.fireCooldown--;
    if (world.fireCooldown <= 0 && world.enemies.length) {
        let target = world.enemies[0];
        let nearest = Infinity;
        for (const enemy of world.enemies) {
            const d = distance(p.x, p.y, enemy.x, enemy.y);
            if (d < nearest) {
                nearest = d;
                target = enemy;
            }
        }
        const angle = Math.atan2(target.y - p.y, target.x - p.x);
        const count = Math.min(3, 1 + Math.floor(world.upgrades.pulse / 3));
        for (let i = 0; i < count; i++) {
            const a = angle + (i - (count - 1) / 2) * .15;
            world.shots.push({ x: p.x, y: p.y, vx: Math.cos(a) * 8, vy: Math.sin(a) * 8, life: 70, damage: 17 + world.upgrades.pulse * 6, hostile: false });
        }
        world.fireCooldown = Math.max(8, 31 - world.upgrades.pulse * 3);
        world.events.push('shot');
    }
    world.novaCooldown--;
    if (world.upgrades.nova > 0 && world.novaCooldown <= 0) {
        const radius = 95 + world.upgrades.nova * 18;
        for (const enemy of world.enemies)
            if (distance(p.x, p.y, enemy.x, enemy.y) < radius) {
                enemy.hp -= 35 + world.upgrades.nova * 16;
                world.events.push('enemy-hit');
                enemy.flash = 8;
            }
        world.effects.push({ x: p.x, y: p.y, kind: 'nova', life: 30, size: radius });
        world.novaCooldown = Math.max(90, 240 - world.upgrades.nova * 15);
    }
    for (const enemy of world.enemies) {
        if (enemy.flash > 0)
            enemy.flash--;
        const angle = Math.atan2(p.y - enemy.y, p.x - enemy.x);
        const d = distance(p.x, p.y, enemy.x, enemy.y);
        const boss = enemy.kind === 'boss' ? campaignBoss : undefined;
        const speed = enemy.kind === 'boss' ? boss?.speed ?? .65 : enemy.kind === 'drone' ? 1.45 : enemy.kind === 'sentry' ? .35 : .8;
        if (enemy.kind !== 'sentry' || d > 230) {
            enemy.x += Math.cos(angle) * speed;
            enemy.y += Math.sin(angle) * speed;
        }
        enemy.attack--;
        if ((enemy.kind === 'sentry' || enemy.kind === 'boss') && enemy.attack <= 0) {
            const count = boss?.shotCount ?? (enemy.kind === 'boss' ? 12 : 1);
            const shotSpeed = boss?.shotSpeed ?? 2.2;
            for (let i = 0; i < count; i++) {
                const a = boss?.aim === 'fan' ? angle + (i - (count - 1) / 2) * boss.fanStep
                    : count === 1 ? angle : i / count * Math.PI * 2 + world.tick * .01;
                world.shots.push({ x: enemy.x, y: enemy.y, vx: Math.cos(a) * shotSpeed, vy: Math.sin(a) * shotSpeed, life: 220, damage: ARMOR_RULES.hpPerCell, hostile: true });
            }
            enemy.attack = boss?.cooldownTicks ?? (enemy.kind === 'boss' ? 135 : 180);
        }
        if (d < enemy.radius + 10)
            damagePlayer(world);
        if (world.upgrades.orbit > 0) {
            const count = Math.min(4, world.upgrades.orbit);
            for (let i = 0; i < count; i++) {
                const a = world.tick * .055 + i * Math.PI * 2 / count;
                if (distance(enemy.x, enemy.y, p.x + Math.cos(a) * 58, p.y + Math.sin(a) * 58) < enemy.radius + 12) {
                    enemy.hp -= 1.3 + world.upgrades.orbit * .3;
                    world.events.push('enemy-hit');
                    enemy.flash = 3;
                }
            }
        }
    }
    for (const shot of world.shots) {
        shot.x += shot.vx;
        shot.y += shot.vy;
        shot.life--;
        if (shot.hostile) {
            if (distance(shot.x, shot.y, p.x, p.y) < 12) {
                damagePlayer(world);
                shot.life = 0;
            }
        }
        else {
            for (const enemy of world.enemies) {
                if (enemy.hp > 0 && distance(shot.x, shot.y, enemy.x, enemy.y) < enemy.radius + 5) {
                    enemy.hp -= shot.damage;
                    world.events.push('enemy-hit');
                    enemy.flash = 6;
                    shot.life = 0;
                    break;
                }
            }
        }
    }
    for (const enemy of world.enemies)
        if (enemy.hp <= 0)
            kill(world, enemy);
    world.enemies = world.enemies.filter(enemy => enemy.hp > 0);
    world.shots = world.shots.filter(shot => shot.life > 0);
    const pickupRadius = 115 + world.upgrades.magnet * 25;
    for (const crystal of world.crystals) {
        const d = distance(p.x, p.y, crystal.x, crystal.y);
        if (d < pickupRadius) {
            crystal.x += (p.x - crystal.x) * .2;
            crystal.y += (p.y - crystal.y) * .2;
            if (d < 14) {
                world.xp += crystal.value;
                crystal.value = 0;
                world.events.push('pickup');
            }
        }
    }
    world.crystals = world.crystals.filter(crystal => crystal.value > 0);
    for (const effect of world.effects)
        effect.life--;
    world.effects = world.effects.filter(effect => effect.life > 0);
    if (world.phase.kind === 'running' && world.xp >= world.threshold) {
        world.xp -= world.threshold;
        world.level++;
        world.threshold = Math.floor(world.threshold * 1.24) + 2;
        world.phase = { kind: 'upgrading', offers: offers(world) };
    }
    if (world.phase.kind === 'running' && world.tick >= rules.durationTicks) {
        world.phase = { kind: world.bossKilled ? 'won' : 'lost' };
        world.events.push(world.bossKilled ? 'won' : 'lost');
    }
}
function hash(data) {
    let value = 2166136261;
    for (let i = 0; i < data.length; i++)
        value = Math.imul(value ^ data.charCodeAt(i), 16777619);
    return (value >>> 0).toString(16).padStart(8, '0');
}
export function checksum(world) {
    const { context, ...battle } = world;
    return hash(JSON.stringify({ ...battle, events: [] }));
}
export function finalChecksum(world) {
    return hash(JSON.stringify([VERSION, world.context.stageId, world.context.rulesVersion, world.seed, checksum(world)]));
}
function object(value) {
    return typeof value === 'object' && value !== null && Object.getPrototypeOf(value) === Object.prototype;
}
function keys(value, expected) {
    if (Reflect.ownKeys(value).length !== expected.length || expected.some(key => !Object.hasOwn(value, key)))
        throw new SimulationError('invalid-data');
}
function parseSeed(value) {
    if (typeof value !== 'number' || !Number.isInteger(value) || value < 0 || value > 4294967295)
        throw new SimulationError('invalid-data');
    return value;
}
function parseAction(value) {
    if (!object(value))
        throw new SimulationError('invalid-data');
    if (value.kind === 'tick') {
        keys(value, ['kind', 'input']);
        if (!object(value.input))
            throw new SimulationError('invalid-data');
        keys(value.input, ['x', 'y', 'dash']);
        const { x, y, dash } = value.input;
        if (typeof x !== 'number' || !Number.isFinite(x) || typeof y !== 'number' || !Number.isFinite(y) || typeof dash !== 'boolean')
            throw new SimulationError('invalid-data');
        return { kind: 'tick', input: Object.freeze({ x, y, dash }) };
    }
    if (value.kind === 'choose') {
        keys(value, ['kind', 'upgrade']);
        const upgrade = UPGRADE_ORDER.find(id => id === value.upgrade);
        if (!upgrade)
            throw new SimulationError('invalid-data');
        return { kind: 'choose', upgrade };
    }
    if (value.kind === 'pause' || value.kind === 'resume') {
        keys(value, ['kind']);
        return { kind: value.kind };
    }
    throw new SimulationError('invalid-data');
}
export function parseActionBuffer(input) {
    if (!object(input))
        throw new SimulationError('invalid-data');
    if (input.version !== VERSION)
        throw new SimulationError('incompatible-version');
    keys(input, ['version', 'stageId', 'rulesVersion', 'seed', 'actions']);
    const context = resolveStage(input.stageId, input.rulesVersion), seed = parseSeed(input.seed);
    if (!Array.isArray(input.actions))
        throw new SimulationError('invalid-data');
    const actions = Array.from(input.actions, value => Object.freeze(parseAction(value)));
    return { version: VERSION, ...context, seed, actions };
}
export function startRecording(world) {
    return { version: VERSION, ...world.context, seed: world.seed, actions: [] };
}
export function finishRecording(world, actions) {
    if (world.phase.kind !== 'won' && world.phase.kind !== 'lost')
        throw new SimulationError('nonterminal-replay');
    const buffer = parseActionBuffer({ ...startRecording(world), actions });
    return Object.freeze({ ...buffer, actions: Object.freeze(buffer.actions), finalChecksum: finalChecksum(world) });
}
export function prepareReplay(input) {
    if (!object(input))
        throw new SimulationError('invalid-data');
    if (input.version !== VERSION)
        throw new SimulationError('incompatible-version');
    keys(input, ['version', 'stageId', 'rulesVersion', 'seed', 'actions', 'finalChecksum']);
    const { finalChecksum: expected, ...prefix } = input;
    const buffer = parseActionBuffer(prefix);
    if (typeof expected !== 'string' || !/^[0-9a-f]{8}$/.test(expected))
        throw new SimulationError('invalid-data');
    const recording = Object.freeze({ ...buffer, actions: Object.freeze(buffer.actions), finalChecksum: expected });
    return { world: createWorld({ stageId: recording.stageId, rulesVersion: recording.rulesVersion, seed: recording.seed }), recording };
}
export function verifyReplay(world, recording, consumedActions) {
    if (consumedActions !== recording.actions.length)
        throw new SimulationError('incomplete-replay');
    if (world.phase.kind !== 'won' && world.phase.kind !== 'lost')
        throw new SimulationError('nonterminal-replay');
    if (world.context.stageId !== recording.stageId || world.context.rulesVersion !== recording.rulesVersion || world.seed !== recording.seed || finalChecksum(world) !== recording.finalChecksum)
        throw new SimulationError('checksum-mismatch');
}
export function replay(input) {
    const { world, recording } = prepareReplay(input);
    for (const action of recording.actions)
        dispatch(world, action);
    verifyReplay(world, recording, recording.actions.length);
    return world;
}
