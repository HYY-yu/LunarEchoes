import { createInitialProgress, decodeProgress, encodeProgress, isStageUnlocked } from './progress.js';
export const PROGRESS_STORAGE_KEY = 'lunar-relay.campaign-progress';
export function openProgressStorage(storage) {
    let progress = createInitialProgress();
    let protection = Object.freeze({ kind: 'ready' });
    let result = Object.freeze({ kind: 'loaded', source: 'missing' });
    const snapshot = () => Object.freeze({ progress, protection, result });
    function finish(next) {
        result = Object.freeze(next);
        return snapshot();
    }
    function read(phase) {
        let raw;
        try {
            raw = storage.getItem(PROGRESS_STORAGE_KEY);
        }
        catch (error) {
            protection = Object.freeze({ kind: 'protected', reason: 'read_error', error });
            finish({ kind: 'not_saved', phase, error });
            return null;
        }
        const decoded = decodeProgress(raw);
        if (decoded.kind === 'rejected') {
            protection = Object.freeze({ kind: 'protected', reason: decoded.reason });
            finish({ kind: 'recovery_required', phase, reason: decoded.reason });
        }
        return decoded;
    }
    function write(target, operation) {
        const expected = encodeProgress(target);
        try {
            storage.setItem(PROGRESS_STORAGE_KEY, expected);
        }
        catch (error) {
            finish({ kind: 'not_saved', phase: operation === 'save' ? 'save_write' : 'reset_write', error });
            return false;
        }
        const phase = operation === 'save' ? 'save_verify' : 'reset_verify';
        let actual;
        try {
            actual = storage.getItem(PROGRESS_STORAGE_KEY);
        }
        catch (error) {
            finish({ kind: 'uncertain', phase, reason: 'read_error', error });
            return false;
        }
        if (actual !== expected) {
            finish({ kind: 'uncertain', phase, reason: 'mismatch' });
            return false;
        }
        return true;
    }
    const loaded = read('load');
    if (loaded?.kind === 'valid') {
        progress = loaded.progress;
        finish({ kind: 'loaded', source: 'valid' });
    }
    return Object.freeze({
        snapshot,
        saveAdvanced(transition) {
            if (transition.kind !== 'advanced')
                throw new TypeError('Expected an advanced progress transition');
            const candidate = transition.progress;
            if (isStageUnlocked({ progress, stageId: candidate.highestUnlockedStageId }))
                return finish({ kind: 'unchanged' });
            progress = Object.freeze({ version: 1, highestUnlockedStageId: candidate.highestUnlockedStageId });
            if (protection.kind === 'protected')
                return finish({ kind: 'protected' });
            const previous = read('save_read');
            if (previous === null || previous.kind === 'rejected')
                return snapshot();
            if (previous.kind === 'valid' && isStageUnlocked({ progress: previous.progress, stageId: progress.highestUnlockedStageId }))
                progress = previous.progress;
            if (write(progress, 'save'))
                finish({ kind: 'saved' });
            return snapshot();
        },
        reset(decision) {
            if (decision === 'cancelled')
                return finish({ kind: 'cancelled' });
            if (decision !== 'confirmed')
                throw new TypeError('Expected an explicit reset decision');
            try {
                storage.getItem(PROGRESS_STORAGE_KEY);
            }
            catch (error) {
                return finish({ kind: 'not_saved', phase: 'reset_read', error });
            }
            const initial = createInitialProgress();
            if (write(initial, 'reset')) {
                progress = initial;
                protection = Object.freeze({ kind: 'ready' });
                finish({ kind: 'reset' });
            }
            return snapshot();
        }
    });
}
